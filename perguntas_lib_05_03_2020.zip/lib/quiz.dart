import 'package:flutter/material.dart';
import 'package:projeto_perguntas/questao.dart';
import 'package:projeto_perguntas/resposta.dart';

class Quiz extends StatelessWidget {
  final List<Map<String, Object>> questions;
  final int selectedQuestions;
  final void Function(int) respond;

  Quiz({
    @required this.questions,
    @required this.selectedQuestions,
    @required this.respond,
  });

  bool get hasSelectedQuestions{
    //size of list is always de last element of list minus one
    //means we have a selected question
    return selectedQuestions < questions.length;
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, Object>> answers =
        hasSelectedQuestions? questions[selectedQuestions]['answers'] : null;

    return Column(
      children: <Widget>[
        Questao(questions[selectedQuestions]['text']),
        ...answers.map((resp) {
          return Resposta(resp['text'], () => respond(resp['score']));
        }).toList()
//            ...widgets,
      ],
    );
  }
}
